package main

import (
	log "github.com/sirupsen/logrus"
	"gitlab.com/gitlab-org/security-products/analyzers/report/v4"
	"gitlab.com/gitlab-org/security-products/analyzers/semgrep/metadata"
	"gitlab.com/gitlab-org/security-products/analyzers/semgrep/sarif"
	"io"
	"os"
)

func convert(reader io.Reader, prependPath string) (*report.Report, error) {
	// HACK: extract root path from environment variables
	// TODO: https://gitlab.com/gitlab-org/gitlab/-/issues/320975
	root := os.Getenv("ANALYZER_TARGET_DIR")
	if root == "" {
		root = os.Getenv("CI_PROJECT_DIR")
	}
	log.Debugf("Converting report with the root path: %s", root)
	sastReport, err := sarif.TransformToGLSASTReport(
		reader,
		"", /* prefix value to trim in relative to the project path. It's empty since we're passing relative project path to semgrep upstream scanner */
		metadata.AnalyzerID,
		metadata.IssueScanner)
	if err != nil {
		return nil, err
	}
	return sastReport, err
}
