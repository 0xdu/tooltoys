package sarif

import (
	log "github.com/sirupsen/logrus"
	"gitlab.com/gitlab-org/security-products/analyzers/report/v4"
	"regexp"
	"strconv"
	"strings"
)

// match CWE-XXX only
var cweIDRegex = regexp.MustCompile(`([cC][wW][eE])-(\d{1,4})`)

// match (TYPE)-(ID): (Description)
var tagIDRegex = regexp.MustCompile(`([^-]+)-([^:]+):\s*(.+)`)

type rule struct {
	ID               string `json:"id"`
	Name             string `json:"name"`
	ShortDescription struct {
		Text string `json:"text"`
	} `json:"shortDescription"`
	FullDescription struct {
		Text string `json:"text"`
	} `json:"fullDescription"`
	DefaultConfiguration struct {
		Level string `json:"level"`
	} `json:"defaultConfiguration"`
	Properties ruleProperties `json:"properties"`
	HelpURI    string         `json:"helpUri"`
	Help       struct {
		Markdown string `json:"markdown"`
		Text     string `json:"text"`
	} `json:"help"`
}

type ruleProperties struct {
	Precision        string   `json:"precision"`
	Tags             []string `json:"tags"`
	SecuritySeverity string   `json:"security-severity"`
}

func findTagMatches(tag string) []string {
	// first try to extract (TAG)-(ID): (Description)
	matches := tagIDRegex.FindStringSubmatch(tag)

	if matches == nil {
		// see if we just have a CWE-(XXX) tag
		matches = cweIDRegex.FindStringSubmatch(tag)
	}
	return matches
}

func (r *rule) Identifiers() []report.Identifier {
	ids := []report.Identifier{}
	for _, tag := range r.Properties.Tags {
		matches := findTagMatches(tag)
		if matches == nil {
			continue
		}

		switch strings.ToLower(matches[1]) {
		case "cwe":
			cweID, err := strconv.Atoi(matches[2])
			if err != nil {
				log.Errorf("Failure to parse CWE ID: %v\n", err)
				continue
			}
			ids = append(ids, report.CWEIdentifier(cweID))
		case "owasp":
			id := matches[2]
			desc := matches[3]
			components := strings.SplitN(matches[3], "-", 2)
			if len(components) == 2 {
				year := strings.TrimSpace(components[0])
				if _, err := strconv.Atoi(year); err == nil {
					id = id + ":" + year
					desc = strings.TrimSpace(components[1])
				}
			}

			ids = append(ids, report.OWASPTop10Identifier(id, desc))
		default:
			ids = append(ids, report.Identifier{
				Type:  report.IdentifierType(strings.ToLower(matches[1])),
				Name:  matches[3],
				Value: matches[2],
			})
		}
	}
	return ids
}

func (r *rule) Message() string {
	// prefer shortDescription field over tag: CWE: <text> for semgrep
	if r.ShortDescription.Text != "" && !strings.EqualFold(r.FullDescription.Text, r.ShortDescription.Text) {
		return r.ShortDescription.Text
	}

	for _, tag := range r.Properties.Tags {
		splits := strings.Split(tag, ":")
		if strings.HasPrefix(splits[0], "CWE") && len(splits) > 1 {
			return strings.TrimLeft(splits[1], " ")
		}
	}
	// default to full text description
	return r.FullDescription.Text
}

func (r *rule) Severity() report.SeverityLevel {
	// if `security-severity` is available, parse it instead of the `DefaultConfiguration` property
	if r.Properties.SecuritySeverity != "" {
		parsedSeverity := report.ParseSeverityLevel(r.Properties.SecuritySeverity)
		securitySeverity := strings.TrimSpace(strings.ToLower(r.Properties.SecuritySeverity))

		if parsedSeverity != report.SeverityLevelUnknown {
			return parsedSeverity
		}
		if strings.EqualFold(securitySeverity, "unknown") {
			return report.SeverityLevelUnknown
		}
	}
	if r.Properties.Precision != "" {
		switch r.Properties.Precision {
		case "very-high":

		}
		switch r.Properties.Precision {
		case "critical":
			return report.SeverityLevelCritical
		case "very-high":
			return report.SeverityLevelCritical
		case "high":
			return report.SeverityLevelHigh
		case "medium":
			return report.SeverityLevelMedium
		case "low":
			return report.SeverityLevelLow
		case "info":
			return report.SeverityLevelInfo
		default:
			return report.SeverityLevelUnknown
		}
	}
	// security-severity was invalid or not provided, fall through to the `DefaultConfiguration` check
	switch r.DefaultConfiguration.Level {
	case "error":
		return report.SeverityLevelCritical
	case "warning":
		return report.SeverityLevelMedium
	case "note":
		return report.SeverityLevelInfo
	case "none":
		return report.SeverityLevelInfo
	default:
		return report.SeverityLevelUnknown
	}
}
