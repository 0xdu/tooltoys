package main

import (
	"fmt"
	log "github.com/sirupsen/logrus"
	"testing"
)

func TestAnalyzer(t *testing.T) {
	log.Info(fmt.Sprintf("THRESHOLD\nCritical: %d\nHigh: %d\nMedium: %d\nLow: %d\n", 1, 2, 3, 4))
}
