# Semgrep analyzer

This analyzer is a wrapper around [Semgrep](https://github.com/returntocorp/semgrep).
It's written in Go using
the [common library](https://gitlab.com/gitlab-org/security-products/analyzers/common)
shared by all analyzers.

The [common library](https://gitlab.com/gitlab-org/security-products/analyzers/common)
contains documentation on how to run, test and modify this analyzer.

## Usage


