package main

import (
	"os"

	log "github.com/sirupsen/logrus"

	"gitlab.com/gitlab-org/security-products/analyzers/command/v2"
	"gitlab.com/gitlab-org/security-products/analyzers/semgrep/metadata"
	"gitlab.com/gitlab-org/security-products/analyzers/semgrep/plugin"
)

func main() {
	app := command.NewApp(metadata.ReportScanner)
	app.Version = metadata.AnalyzerVersion
	if metadata.ReportScanner.Version == "" {
		metadata.ReportScanner.Version = "1.0"
	}
	app.Commands = command.NewCommands(command.Config{
		Match:        plugin.Match,
		Analyze:      analyze,
		AnalyzeFlags: analyzeFlags(),
		AnalyzeAll:   true,
		Convert:      convert,
		Analyzer:     metadata.ReportScanner,
		Scanner:      metadata.ReportScanner,
		ScanType:     metadata.Type,
	})
	app.Commands = append(app.Commands, ThresholdCommand())
	if err := app.Run(os.Args); err != nil {
		log.Fatal(err)
	}
}
