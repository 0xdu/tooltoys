package main

import (
	"testing"
)

func TestThreshold(t *testing.T) {
	threshold := Threshold{
		Critical:       40,
		High:           0,
		Medium:         0,
		Low:            0,
		SastReportPath: "testdata/reports/sast.json",
	}
	threshold.Verify()
}
