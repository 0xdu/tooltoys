package main

import (
	log "github.com/sirupsen/logrus"
	"io"
	"os"
	"os/exec"
	"path"
	"strings"
	"syscall"
)

var invalidExitCodes = map[int]bool{
	1: false, // Semgrep found issues in your code
	// In the case of `2` we must inspect the SARIF output, so this is handled within the ConvertFunc
	// i.e. nosem mismatch
	2: false, // Semgrep failed
	4: true,  // Semgrep encountered an invalid pattern
	7: true,  // All rules in config are invalid
}

type Analyzer struct {
	Configs       string
	Severities    string
	ProEngine     bool
	ExcludedPaths string
}

func (this *Analyzer) Analyze(projectPath string) (io.ReadCloser, error) {
	outputPath := path.Join(projectPath, "semgrep.sarif")
	args := this.Args(outputPath)
	cmd := exec.Command("semgrep", args...) // #nosec G204
	log.Debug(cmd.String())
	cmd.Dir = projectPath
	cmd.Env = os.Environ()
	cmd.Env = append(cmd.Env, "SEMGREP_USER_AGENT_APPEND=(GitLab SAST)")

	output, err := cmd.CombinedOutput()

	if err != nil {
		log.Debugf("%s", output)

		if exitError, ok := err.(*exec.ExitError); ok {
			waitStatus := exitError.Sys().(syscall.WaitStatus)

			if invalidExitCodes[waitStatus.ExitStatus()] {
				return nil, err
			}
		}
	}

	return os.Open(outputPath)
}

func (this *Analyzer) Args(outputPath string) []string {
	args := []string{
		"-o", outputPath,
		"--sarif",
		"--no-rewrite-rule-ids",
		"--disable-version-check",
		"--no-git-ignore",
		"--dataflow-traces",
		"--skip-unknown-extensions",
		"--use-git-ignore",
	}
	if strings.TrimSpace(this.ExcludedPaths) != "" {
		excludes := strings.Split(this.ExcludedPaths, ",")
		for _, exclude := range excludes {
			args = append(args, "--exclude", strings.TrimSpace(exclude))
		}
	}
	if strings.TrimSpace(this.ExcludedPaths) != "" {
		severities := strings.Split(this.Severities, ",")
		for _, severity := range severities {
			if severity == "INFO" || severity == "WARNING" || severity == "ERROR" {
				args = append(args, "--severity", strings.TrimSpace(severity))
			}
		}
	}

	if this.ProEngine {
		args = append(args, "--pro")
	}

	if strings.TrimSpace(this.Configs) != "" {
		configs := strings.Split(this.Configs, ",")
		for _, config := range configs {
			args = append(args, "--config", strings.TrimSpace(config))
		}
	}
	if level, ok := os.LookupEnv("SECURE_LOG_LEVEL"); ok && strings.ToLower(level) == "debug" {
		args = append(args, "--verbose")
	}

	return args
}
