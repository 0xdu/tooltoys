# RuleRascal

This project tries to improve rule messages with ChatGPT. It named itself and explained:

> The name "RuleRascal" suggests that the program is capable of creating rules for your code that are a little bit playful or mischievous. However, this doesn't mean that the rules it creates will be difficult to understand or tricky to follow – in fact, the opposite is true. The program is designed to help you create clear and easy-to-understand rules for your code, so that you can quickly and easily find and fix any potential issues. By using RuleRascal, you can create rules that are effective and straightforward, without sacrificing any of the fun or creativity that goes into writing code.
