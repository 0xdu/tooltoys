// ruleid: dynatrace-api-token
dynatrace_api_token = "dt0c01.6rm7jcwbb3fmtfzkyepf16kj.3l8arrff1ozxlllxrzel9usoanieedfliwwnmuq5z6vbhogdykznemtv2k7y270q"
