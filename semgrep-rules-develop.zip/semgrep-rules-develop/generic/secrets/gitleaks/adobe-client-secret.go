// ruleid: adobe-client-secret
adobeClient := "p8e-c4335bf6dbb3415db56bd7f2017a5eae"