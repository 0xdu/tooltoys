// ruleid: discord-client-secret
discord_api_token = "47050061723854045311518666050614"