// ruleid: digitalocean-pat
do_api_token = "dop_v1_e88808ddd29a7b331068e5521e6739a21fa06b3c62a2fdb0dd054483909dbaa3"
