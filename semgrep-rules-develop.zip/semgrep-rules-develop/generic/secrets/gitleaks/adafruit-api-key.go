// ruleid: adafruit-api-key
adafruit_api_token = "9zu9r6idf9c0tfcc4w26l66ij7visb8n"