// ruleid: confluent-secret-key
confluent_api_token = "l2ug6iykc7kouc3no9x07tdufvlmj2dsxcqe00nef3ca5o9x8iv68nmsoll50uk6"