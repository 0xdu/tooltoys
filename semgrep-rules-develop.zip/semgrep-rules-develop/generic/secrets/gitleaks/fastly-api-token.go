// ruleid: fastly-api-token
fastly_api_token = "5u4ytc6q1du0c94n8hl5z_--p-jdae0l"
