// ruleid: digitalocean-access-token
do_api_token = "doo_v1_01668ac5824f09ce908aaff8bf60e08c375e707f36b73dd2df0994887bbb9799"
