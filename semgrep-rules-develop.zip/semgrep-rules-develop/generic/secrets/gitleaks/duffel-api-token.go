// ruleid: duffel-api-token
duffel_api_token = "duffel_test_bhz4paljza_dx-f20xclnulzqiq2k68akarsy7lc7-a"
