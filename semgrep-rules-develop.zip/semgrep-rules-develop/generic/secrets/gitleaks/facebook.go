// ruleid: facebook
facebook_api_token = "2c48da94029b0ea566ac3df604803767"