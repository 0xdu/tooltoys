// ruleid: algolia-api-key
algolia_key := df161d9d584191ce8274164d16b433c6