// ruleid: adobe-client-id
adobe_api_token = "90ade2687249df5f415099b431b31fae"