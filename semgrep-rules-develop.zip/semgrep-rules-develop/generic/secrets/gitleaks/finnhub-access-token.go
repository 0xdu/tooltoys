// ruleid: finnhub-access-token
finnhub_api_token = "r5bcoxh2rfhexu4hmyc8