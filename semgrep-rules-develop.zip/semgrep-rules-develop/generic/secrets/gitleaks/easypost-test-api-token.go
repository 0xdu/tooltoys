// ruleid: easypost-test-api-token
EZTK_api_token = "EZTKcb422hlnssf48n4gt6hp24kksir0akoa9kit98wufmvoqd2tj9sy3k"