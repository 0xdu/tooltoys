# Contributions

We welcome contributions to this repo! Please fork and make a pull request; we'll contact you about signing our CLA.

See [Contributing to Semgrep rules](https://semgrep.dev/docs/contributing/contributing-to-semgrep-rules-repository/) in our docs page for more information on how you can contribute!

We're happy to help!

- Email us: [support@r2c.dev](mailto:support@r2c.dev)
- [Join our Slack](https://r2c.dev/slack)
