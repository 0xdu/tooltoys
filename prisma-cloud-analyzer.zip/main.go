package main

import (
	"errors"
	log "github.com/sirupsen/logrus"
	"github.com/urfave/cli/v2"
	"gitlab.com/gitlab-org/security-products/analyzers/common/v3/logutil"
	"gitlab.com/gitlab-org/security-products/analyzers/report/v4"
	"os"
	"prisma-cloud-analyzer/metadata"
	"time"
)

const (
	ArtifactNameDependencyScanning = "gl-dependency-scanning-report.json"
	ArtifactNameContainerScanning  = "gl-container-scanning-report.json"
)

func main() {
	app := cli.NewApp()
	app.Name = metadata.AnalyzerName
	app.Version = metadata.AnalyzerVersion
	app.Authors = []*cli.Author{{Name: metadata.AnalyzerVendor}}
	app.Usage = metadata.AnalyzerUsage

	log.SetFormatter(&logutil.Formatter{Project: metadata.AnalyzerName})
	log.Info(metadata.AnalyzerUsage)

	if metadata.ReportScanner.Version == "" {
		metadata.ReportScanner.Version = "1.0"
	}
	app.Commands = []*cli.Command{
		&cli.Command{
			Name:      "container",
			Usage:     "Analyze scan container and generate report",
			ArgsUsage: "<project-dir>",
			Flags:     scanContainerFlags(),
			Action: func(c *cli.Context) error {
				startTime := report.ScanTime(time.Now())
				// no args
				if c.Args().Present() {
					if err := cli.ShowSubcommandHelp(c); err != nil {
						return err
					}
					return errors.New("Invalid arguments")
				}
				// analyze
				log.Info("Running analyzer")
				analyzer := NewAnalyzer(c)
				f, err := analyzer.ScanContainer()
				if err != nil {
					return err
				}
				defer f.Close()
				// convert
				log.Info("Creating report")
				newReport, err := convertContainerReport(f, analyzer.TargetDir)
				if err != nil {
					return err
				}
				endTime := report.ScanTime(time.Now())
				newReport.Scan.StartTime = &startTime
				newReport.Scan.EndTime = &endTime
				newReport.Sort()
				if err = SerializeJSONToFile(newReport, ArtifactNameContainerScanning, "", false, false); err != nil {
					cerr := f.Close()
					if cerr != nil {
						return cerr
					}
					return err
				}
				return f.Close()
			},
		},
		&cli.Command{
			Name:      "sca",
			Usage:     "Analyze sca project and generate report",
			ArgsUsage: "<project-dir>",
			Flags:     scanSCAFlags(),
			Action: func(c *cli.Context) error {
				startTime := report.ScanTime(time.Now())
				// no args
				if c.Args().Present() {
					if err := cli.ShowSubcommandHelp(c); err != nil {
						return err
					}
					return errors.New("Invalid arguments")
				}
				// analyze
				log.Info("Running analyzer")
				analyzer := NewAnalyzer(c)
				f, err := analyzer.ScanSCA()
				if err != nil {
					return err
				}
				defer f.Close()
				// convert
				log.Info("Creating report")
				newReport, err := convertSCAReport(f, analyzer.TargetDir)
				if err != nil {
					return err
				}
				endTime := report.ScanTime(time.Now())
				newReport.Scan.StartTime = &startTime
				newReport.Scan.EndTime = &endTime
				newReport.Sort()
				if err = SerializeJSONToFile(newReport, ArtifactNameDependencyScanning, "", false, false); err != nil {
					cerr := f.Close()
					if cerr != nil {
						return cerr
					}
					return err
				}
				return f.Close()
			},
		},
	}

	if err := app.Run(os.Args); err != nil {
		log.Fatal(err)
	}
}
