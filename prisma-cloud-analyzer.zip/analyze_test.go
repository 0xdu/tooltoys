package main

import (
	"testing"
)

func TestAnalyzer(t *testing.T) {

}
