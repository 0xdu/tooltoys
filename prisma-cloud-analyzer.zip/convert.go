package main

import (
	"encoding/json"
	"fmt"
	report "gitlab.com/gitlab-org/security-products/analyzers/report/v4"
	"io"
	"io/ioutil"
	"prisma-cloud-analyzer/metadata"
	"strings"
)

func convertContainerReport(reader io.Reader, prePath string) (*report.Report, error) {
	buf, err := ioutil.ReadAll(reader)
	if err != nil {
		return nil, err
	}
	var scanner = report.Scanner{
		ID:   metadata.AnalyzerID,
		Name: metadata.AnalyzerName,
	}
	var rep ContainerReport
	_ = json.Unmarshal(buf, &rep)
	var issues []report.Vulnerability
	for _, result := range rep.Results {
		for _, vuln := range result.Vulnerabilities {
			identifer, _ := report.ParseIdentifierID(vuln.Id)
			issue := report.Vulnerability{
				Name:        fmt.Sprintf("%s - %s version %s", vuln.Id, vuln.PackageName, vuln.PackageVersion),
				Title:       fmt.Sprintf("%s - %s version %s", vuln.Id, vuln.PackageName, vuln.PackageVersion),
				Category:    report.CategoryContainerScanning,
				Scanner:     &scanner,
				Description: vuln.Description,
				Severity:    severityLevel(vuln.Severity),
				CompareKey:  vuln.Id,
				Links: []report.Link{
					{
						Name: vuln.Link,
						URL:  vuln.Link,
					},
				},
				Identifiers: []report.Identifier{
					identifer,
				},
				Location: report.Location{
					Dependency: &report.Dependency{
						Package: report.Package{
							Name: vuln.PackageName,
						},
						Version: vuln.PackageVersion,
					},
					OperatingSystem: result.Distro,
					Image:           result.Name,
				},
				Solution: vuln.Status,
			}
			issues = append(issues, issue)
		}
	}
	newReport := report.NewReport()
	newReport.Vulnerabilities = issues
	newReport.Analyzer = metadata.AnalyzerID
	newReport.Version = report.CurrentVersion()
	newReport.Scan.Scanner = metadata.ReportScanner
	newReport.Scan.Type = report.CategoryContainerScanning
	newReport.Scan.Status = report.StatusSuccess
	return &newReport, nil
}

func convertSCAReport(reader io.Reader, prePath string) (*report.Report, error) {
	buf, err := ioutil.ReadAll(reader)
	if err != nil {
		return nil, err
	}
	var scanner = report.Scanner{
		ID:   metadata.AnalyzerID,
		Name: metadata.AnalyzerName,
	}
	var rep SCAReport
	_ = json.Unmarshal(buf, &rep)
	var issues []report.Vulnerability
	for _, vuln := range rep.Vulnerabilities {
		identifer, _ := report.ParseIdentifierID(vuln.Id)
		issue := report.Vulnerability{
			Name:        fmt.Sprintf("%s - %s version %s", vuln.Id, vuln.PackageName, vuln.PackageVersion),
			Title:       vuln.Id,
			Category:    report.CategoryDependencyScanning,
			Scanner:     &scanner,
			Description: vuln.Description,
			Severity:    severityLevel(vuln.Severity),
			CompareKey:  vuln.Id,
			Links: []report.Link{
				{
					Name: vuln.Link,
					URL:  vuln.Link,
				},
			},
			Identifiers: []report.Identifier{
				identifer,
			},
			Location: report.Location{
				Dependency: &report.Dependency{
					Package: report.Package{
						Name: vuln.PackageName,
					},
					Version: vuln.PackageVersion,
				},
				File: "",
			},
			Solution: vuln.Status,
		}
		issues = append(issues, issue)
	}
	mDependencies := make(map[string]report.DependencyFile)
	for _, pack := range rep.Packages {
		path := strings.ReplaceAll(pack.Path, prePath, "")
		dependencyFile, ok := mDependencies[path]
		if ok == false {
			mDependencies[path] = report.DependencyFile{
				Path:           path,
				PackageManager: "",
				Dependencies:   []report.Dependency{},
			}
		}
		dependencyFile.Dependencies = append(dependencyFile.Dependencies, report.Dependency{
			Package: report.Package{
				Name: strings.ReplaceAll(pack.Name, "_", "/"),
			},
			Version: pack.Version,
		})
	}
	newReport := report.NewReport()
	for _, dependencyFile := range mDependencies {
		newReport.DependencyFiles = append(newReport.DependencyFiles, dependencyFile)
	}
	newReport.Vulnerabilities = issues
	newReport.Analyzer = metadata.AnalyzerID
	newReport.Version = report.CurrentVersion()
	newReport.Scan.Scanner = metadata.ReportScanner
	newReport.Scan.Type = report.CategoryDependencyScanning
	newReport.Scan.Status = report.StatusSuccess
	return &newReport, nil
}

// severityLevel converts severity to a generic severity level.
func severityLevel(s string) report.SeverityLevel {
	s = strings.ToLower(s)
	switch s {
	case "critical":
		return report.SeverityLevelCritical
	case "high":
		return report.SeverityLevelHigh
	case "medium":
		return report.SeverityLevelMedium
	case "moderate":
		return report.SeverityLevelMedium
	case "low":
		return report.SeverityLevelLow
	case "info":
		return report.SeverityLevelInfo
	}
	return report.SeverityLevelUnknown
}
