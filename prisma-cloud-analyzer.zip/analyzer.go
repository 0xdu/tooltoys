package main

import (
	"bufio"
	log "github.com/sirupsen/logrus"
	"github.com/urfave/cli/v2"
	"io"
	"os"
	"os/exec"
)

type Analyzer struct {
	TargetDir     string
	TwistCliPath  string
	ConsoleUrl    string
	User          string
	Password      string
	OutputFile    string
	DockerAddress string
	ShowDetail    bool
	Image         string
	RepoName      string
	RepoPath      string
}

func NewAnalyzer(c *cli.Context) *Analyzer {
	return &Analyzer{
		TargetDir:     c.String(FlagTargetDir),
		TwistCliPath:  c.String(FlagTwistCliPath),
		ConsoleUrl:    c.String(FlagUrl),
		User:          c.String(FlagUser),
		Password:      c.String(FlagPass),
		OutputFile:    c.String(FlagOutput),
		DockerAddress: c.String(FlagDockerAddress),
		ShowDetail:    c.Bool(FlagDetails),
		Image:         c.String(FlagImage),
		RepoName:      c.String(FlagRepoName),
		RepoPath:      c.String(FlagRepoPath),
	}
}

func (this *Analyzer) ScanContainer() (io.ReadCloser, error) {
	var err error
	defer func() {
		if err != nil {
			log.Error("Analyze error: " + err.Error())
			os.Exit(2)
		} else {
			log.Info("Analyze success")
		}
	}()
	//images scan  --docker-address $DOCKER_HOST --address $PCC_CONSOLE_URL --user $PCC_USER --password $PCC_PASS --output-file scan-results.json --details $IMAGE_NAME
	args := []string{
		"images", "scan",
		"--docker-address", this.DockerAddress,
		"--address", this.ConsoleUrl,
		"--user", this.User,
		"--password", this.Password,
		"--output-file", this.OutputFile,
	}
	if this.ShowDetail {
		args = append(args, "--details")
	}
	args = append(args, this.Image)
	cmd := exec.Command(this.TwistCliPath, args...)
	cmd.Env = os.Environ()
	stdout, _ := cmd.StdoutPipe()
	err = cmd.Start()
	if err != nil {
		return nil, err
	}
	go printStdout(stdout)
	err = cmd.Wait()
	return os.Open(this.OutputFile)
}

func (this *Analyzer) ScanSCA() (io.ReadCloser, error) {
	var err error
	defer func() {
		if err != nil {
			log.Error("Analyze error: " + err.Error())
			os.Exit(2)
		} else {
			log.Info("Analyze success")
		}
	}()
	//images scan  --docker-address $DOCKER_HOST --address $PCC_CONSOLE_URL --user $PCC_USER --password $PCC_PASS --output-file scan-results.json --details $IMAGE_NAME
	args := []string{
		"coderepo", "scan",
		"--address", this.ConsoleUrl,
		"--user", this.User,
		"--password", this.Password,
		"--output-file", this.OutputFile,
		"--repository", this.RepoName,
	}
	if this.ShowDetail {
		args = append(args, "--details")
	}
	args = append(args, this.RepoPath)
	cmd := exec.Command(this.TwistCliPath, args...)
	cmd.Env = os.Environ()
	stdout, _ := cmd.StdoutPipe()
	err = cmd.Start()
	if err != nil {
		return nil, err
	}
	go printStdout(stdout)
	err = cmd.Wait()
	return os.Open(this.OutputFile)
}

func printStdout(stdout io.ReadCloser) {
	reader := bufio.NewReader(stdout)
	line, _, err := reader.ReadLine()
	for {
		if err != nil || line == nil {
			break
		}
		log.Println(string(line))
		line, _, err = reader.ReadLine()
	}
}
