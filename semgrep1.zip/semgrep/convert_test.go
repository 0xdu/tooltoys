package main

import (
	"encoding/json"
	"os"
	"testing"

	"github.com/stretchr/testify/require"
)

func TestConvert(t *testing.T) {
	fixture, err := os.Open("testdata/reports/semgrep.json")
	require.NoError(t, err)
	defer fixture.Close()
	sastReport, err := convert(fixture, "")
	data, _ := json.Marshal(sastReport)
	os.WriteFile("testdata/reports/sast.json", data, 777)
}
