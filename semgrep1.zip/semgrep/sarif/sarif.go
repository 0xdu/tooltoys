package sarif

import (
	"bytes"
	"encoding/json"
	"fmt"
	"gitlab.com/gitlab-org/security-products/analyzers/report/v4"
	"gitlab.com/gitlab-org/security-products/analyzers/ruleset/v2"
	"io"
	"strings"
)

const vulnerabilityMessageMaxLengthBytes = 1048576

func TransformToGLSASTReport(reader io.Reader, rootPath, analyzerID string, scanner report.Scanner) (*report.Report, error) {
	s := sarif{}
	jsonBytes, err := readerToBytes(reader)
	if err != nil {
		return nil, err
	}

	err = json.Unmarshal(jsonBytes, &s)
	if err != nil {
		return nil, err
	}
	newReport := report.NewReport()
	var allVulns []report.Vulnerability
	// It is generally expected to only have a single run, but best to parse all as it is a collection.
	for _, run := range s.Runs {
		vulns, err := transformRun(run, rootPath, scanner)
		if err != nil {
			return nil, err
		}

		allVulns = append(allVulns, vulns...)
	}
	newReport.Analyzer = analyzerID
	newReport.Config.Path = ruleset.PathSAST
	newReport.Vulnerabilities = allVulns
	return &newReport, nil
}

func readerToBytes(reader io.Reader) ([]byte, error) {
	buf := new(bytes.Buffer)
	_, err := buf.ReadFrom(reader)
	if err != nil {
		return nil, err
	}

	return buf.Bytes(), nil
}

func transformRun(r run, rootPath string, scanner report.Scanner) ([]report.Vulnerability, error) {
	ruleMap := make(map[string]rule)
	for _, rule := range r.Tool.Driver.Rules {
		ruleMap[rule.ID] = rule
	}

	var vulns []report.Vulnerability
	for _, result := range r.Results {
		if shouldSuppress(result) {
			continue
		}
		rule := ruleMap[result.RuleID]
		var description string
		if len(result.Message.Text) > vulnerabilityMessageMaxLengthBytes {
			description = result.Message.Text[:vulnerabilityMessageMaxLengthBytes]
		} else {
			description = result.Message.Text
			codeFlow := result.Flow()
			if codeFlow != "" {
				description += fmt.Sprintf("\n##### Vulnerability Flow\n%s", codeFlow)
			}
		}
		identifiers := rule.Identifiers()
		identifiers = append(identifiers, primaryIdentifier(rule, scanner))
		for _, location := range result.Locations {
			lineEnd := location.PhysicalLocation.Region.EndLine
			vuln := report.Vulnerability{
				CompareKey:  result.Fingerprints.Id,
				Description: description,
				Category:    report.CategorySast,
				Message:     rule.Message(),
				Severity:    rule.Severity(),
				Scanner:     &scanner,
				Location: report.Location{
					File:      removeRootPath(location.PhysicalLocation.ArtifactLocation.Uri, rootPath),
					LineStart: location.PhysicalLocation.Region.StartLine,
					LineEnd:   lineEnd,
				},
				Identifiers: identifiers,
			}
			if vuln.CompareKey == "" {
				vuln.CompareKey = computeCompareKey(vuln)
			}
			vulns = append(vulns, vuln)
			break
		}
	}
	return vulns, nil
}

func primaryIdentifier(r rule, scanner report.Scanner) report.Identifier {
	return report.Identifier{
		Type:  report.IdentifierType(scanner.ID),
		Name:  scanner.Name,
		Value: r.ID,
		URL:   r.HelpURI,
	}
}

func computeCompareKey(v report.Vulnerability) string {
	return strings.Join(
		[]string{
			string(v.Identifiers[0].Type),
			v.Identifiers[0].Value,
			fmt.Sprint(v.Location.LineStart),
			fmt.Sprint(v.Location.LineEnd),
		}, ":")
}
func shouldSuppress(r result) bool {
	if len(r.Suppressions) == 0 {
		return false
	}
	for _, sup := range r.Suppressions {
		// if one of the suppressions is under review or rejected, include
		// the finding in the artifact.
		if sup.Status == "underReview" || sup.Status == "rejected" {
			return false
		}
	}
	return true
}

func removeRootPath(path, rootPath string) string {
	prefix := strings.TrimSuffix(rootPath, "/") + "/"
	if path[0] != '/' {
		prefix = strings.TrimPrefix(prefix, "/")
	}

	return strings.TrimPrefix(path, prefix)
}
