package main

import (
	"encoding/json"
	"fmt"
	log "github.com/sirupsen/logrus"
	"github.com/urfave/cli/v2"
	"gitlab.com/gitlab-org/security-products/analyzers/command/v2"
	"gitlab.com/gitlab-org/security-products/analyzers/report/v4"
	"os"
)

var flagPath = "report-file"
var flagThresholdCritical = "critical"
var flagThresholdHigh = "high"
var flagThresholdMedium = "medium"
var flagThresholdLow = "low"

type Threshold struct {
	Critical       int
	High           int
	Medium         int
	Low            int
	SastReportPath string
}

func (this *Threshold) Verify() {
	if this.Critical <= 0 && this.High <= 0 && this.Medium <= 0 && this.Low <= 0 {
		return
	}
	data, err := os.ReadFile(this.SastReportPath)
	if err != nil {
		log.Error("Read sast report error: " + err.Error())
		os.Exit(1)
		return
	}
	sastReport := report.Report{}
	err = json.Unmarshal(data, &sastReport)
	if err != nil {
		log.Error("Convert sast report error: " + err.Error())
		os.Exit(1)
		return
	}
	severities := map[report.SeverityLevel]int{
		report.SeverityLevelCritical:  0,
		report.SeverityLevelHigh:      0,
		report.SeverityLevelMedium:    0,
		report.SeverityLevelLow:       0,
		report.SeverityLevelInfo:      0,
		report.SeverityLevelUnknown:   0,
		report.SeverityLevelUndefined: 0,
	}
	threshold := map[report.SeverityLevel]int{
		report.SeverityLevelCritical: this.Critical,
		report.SeverityLevelHigh:     this.High,
		report.SeverityLevelMedium:   this.Medium,
		report.SeverityLevelLow:      this.Low,
	}
	block := false
	for _, vuln := range sastReport.Vulnerabilities {
		severities[vuln.Severity] += 1
		if threshold[vuln.Severity] > 0 && severities[vuln.Severity] >= threshold[vuln.Severity] {
			block = true
			break
		}
	}
	log.Info(fmt.Sprintf("Threshold\nCritical: %d\nHigh: %d\nMedium: %d\nLow: %d\n", this.Critical, this.High, this.Medium, this.Low))
	if block {
		log.Error("Threshold Status: Fail")
		os.Exit(1)
	} else {
		log.Info("Threshold Status: Success")
	}
}

func ThresholdCommand() *cli.Command {
	flags := []cli.Flag{
		&cli.StringFlag{
			Name:    flagPath,
			Aliases: []string{"f"},
			Usage:   "Path to SAST report file",
			Value:   command.ArtifactNameSAST,
		},
		&cli.IntFlag{
			Name:    flagThresholdCritical,
			Usage:   "Threshold CRITICAL issue",
			Value:   0,
			EnvVars: []string{"SAST_THRESHOLD_CRITICAL"},
		},
		&cli.IntFlag{
			Name:    flagThresholdHigh,
			Usage:   "Threshold HIGH issue",
			Value:   0,
			EnvVars: []string{"SAST_THRESHOLD_HIGH"},
		},
		&cli.IntFlag{
			Name:    flagThresholdMedium,
			Usage:   "Threshold MEDIUM issue",
			Value:   0,
			EnvVars: []string{"SAST_THRESHOLD_MEDIUM"},
		},
		&cli.IntFlag{
			Name:    flagThresholdLow,
			Usage:   "Threshold LOW issue",
			Value:   0,
			EnvVars: []string{"SAST_THRESHOLD_LOW"},
		},
	}

	return &cli.Command{
		Name:  "threshold",
		Usage: "Threshold the sast result",
		Flags: flags,
		Action: func(c *cli.Context) error {
			threshold := Threshold{
				Critical:       c.Int(flagThresholdCritical),
				High:           c.Int(flagThresholdHigh),
				Medium:         c.Int(flagThresholdMedium),
				Low:            c.Int(flagThresholdLow),
				SastReportPath: c.String(flagPath),
			}
			threshold.Verify()
			return nil
		},
	}
}
