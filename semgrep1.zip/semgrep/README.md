# Semgrep analyzer

This analyzer is a wrapper around [Semgrep](https://github.com/returntocorp/semgrep).
It's written in Go using
the [common library](https://gitlab.com/gitlab-org/security-products/analyzers/common)
shared by all analyzers.

The [common library](https://gitlab.com/gitlab-org/security-products/analyzers/common)
contains documentation on how to run, test and modify this analyzer.

## Usage
```yaml
/analyzer run
/analyzer threshold
```

### Env Variable
| ENV                     | Description                                                                                        |
|-------------------------|----------------------------------------------------------------------------------------------------|
| SAST_EXCLUDED_PATHS     | Excluded path to scan                                                                              |
| SAST_SEMGREP_SEVERITY   | Filter rule by severity. `SAST_SEMGREP_SEVERITY: INFO,WARNING,ERROR`                               |
| SAST_SEMGREP_CONFIG     | Path to config rules. `SAST_SEMGREP_CONFIG: http://repo.vps.com.vn/repository/cicd/c/p/sast_rules` |
| SAST_THRESHOLD_CRITICAL | Threshold critical vulnerability. Default 0.                                                       |
| SAST_THRESHOLD_HIGH     | Threshold high vulnerability. Default 0.                                                           |
| SAST_THRESHOLD_MEDIUM   | Threshold medium vulnerability. Default 0.                                                         |
| SAST_THRESHOLD_LOW      | Threshold low vulnerability. Default 0.                                                            |
