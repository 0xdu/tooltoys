package main

import (
	"bufio"
	log "github.com/sirupsen/logrus"
	"io"
	"os"
	"os/exec"
	"strings"
)

var invalidExitCodes = map[int]bool{
	1: false, // Semgrep found issues in your code
	// In the case of `2` we must inspect the SARIF output, so this is handled within the ConvertFunc
	// i.e. nosem mismatch
	2: false, // Semgrep failed
	4: true,  // Semgrep encountered an invalid pattern
	7: true,  // All rules in config are invalid
}

func printStdout(stdout io.ReadCloser) {
	reader := bufio.NewReader(stdout)
	line, _, err := reader.ReadLine()
	for {
		if err != nil || line == nil {
			break
		}
		log.Println(string(line))
		line, _, err = reader.ReadLine()
	}
}

type Analyzer struct {
	Configs       string
	Severities    string
	ProEngine     bool
	ExcludedPaths string
}

func (this *Analyzer) Analyze(projectPath string) (io.ReadCloser, error) {
	outputPath := "semgrep.sarif"
	args := this.Args(outputPath)
	cmd := exec.Command("semgrep", args...) // #nosec G204
	log.Debug(cmd.String())
	cmd.Env = os.Environ()
	stdout, _ := cmd.StdoutPipe()
	err := cmd.Start()
	if err != nil {
		return nil, err
	}
	go printStdout(stdout)
	err = cmd.Wait()
	return os.Open(outputPath)
}

func (this *Analyzer) Args(outputPath string) []string {
	args := []string{
		"-o", outputPath,
		"--sarif",
		"--no-rewrite-rule-ids",
		"--disable-version-check",
		"--no-git-ignore",
		"--dataflow-traces",
		"--skip-unknown-extensions",
		"--use-git-ignore",
		".",
	}
	if strings.TrimSpace(this.ExcludedPaths) != "" {
		excludes := strings.Split(this.ExcludedPaths, ",")
		for _, exclude := range excludes {
			args = append(args, "--exclude", strings.TrimSpace(exclude))
		}
	}
	if strings.TrimSpace(this.ExcludedPaths) != "" {
		severities := strings.Split(this.Severities, ",")
		for _, severity := range severities {
			if severity == "INFO" || severity == "WARNING" || severity == "ERROR" {
				args = append(args, "--severity", strings.TrimSpace(severity))
			}
		}
	}

	if this.ProEngine {
		args = append(args, "--pro")
	}

	if strings.TrimSpace(this.Configs) != "" {
		configs := strings.Split(this.Configs, ",")
		for _, config := range configs {
			args = append(args, "--config", strings.TrimSpace(config))
		}
	}
	if level, ok := os.LookupEnv("SECURE_LOG_LEVEL"); ok && strings.ToLower(level) == "debug" {
		args = append(args, "--verbose")
	}

	return args
}
