package main

import (
	"github.com/urfave/cli/v2"
	"io"
)

const (
	flagExclude    = "exclude"
	flagProMode    = "pro"
	flagConfigs    = "config"
	flagSeverities = "severity"
)

func analyzeFlags() []cli.Flag {
	return []cli.Flag{
		&cli.BoolFlag{
			Name:    flagProMode,
			Usage:   "Inter-file analysis and Pro languages. Requires Semgrep Pro Engine",
			EnvVars: []string{"SAST_SEMGREP_PRO"},
			Value:   true,
		},
		&cli.StringFlag{
			Name:    flagExclude,
			Usage:   "Skip any file or directory that matches this pattern",
			EnvVars: []string{"SAST_EXCLUDED_PATHS"},
			Value:   "",
		},
		&cli.StringFlag{
			Name:    flagSeverities,
			Usage:   "Skip any file or directory that matches this pattern",
			EnvVars: []string{"SAST_SEMGREP_SEVERITY"},
			Value:   "",
		},
		&cli.StringFlag{
			Name:     flagConfigs,
			Required: true,
			Usage:    "YAML configuration file, directory of YAML files ending in .yml|.yaml, URL of a configuration file, or Semgrep registry entry name.",
			EnvVars:  []string{"SAST_SEMGREP_CONFIG"},
		},
	}
}

func analyze(c *cli.Context, projectPath string) (io.ReadCloser, error) {
	scanner := Analyzer{
		Configs:       c.String(flagConfigs),
		Severities:    c.String(flagSeverities),
		ProEngine:     c.Bool(flagProMode),
		ExcludedPaths: c.String(flagExclude),
	}
	return scanner.Analyze(projectPath)
}
